package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText editText_sayilar;
    Button button_TekSayi,button_CiftSayi,button_TumSayi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText_sayilar=findViewById(R.id.editTextTextMultiLine_Sayilar);
        button_TumSayi=findViewById(R.id.button_TumSayilar);
        button_TekSayi=findViewById(R.id.button_TekSayilar);
        button_CiftSayi=findViewById(R.id.button_CiftSayilar);
    }
    public  void  ciftSayilar(View View){
        editText_sayilar.setText("");
        for (int i=0;i<=15;i++){
            if(i%2==0){
                editText_sayilar.setText(editText_sayilar.getText()+"\n"+i);
            }
        }
    }
    public  void  tekSayilar(View View){
        editText_sayilar.setText("");
        for (int i=0;i<=15;i++){
            if(i%2!=0){
                editText_sayilar.setText(editText_sayilar.getText()+"\n"+i);
            }
        }
    }

    public  void  tumSayilar(View View){
        editText_sayilar.setText("");
        for (int i=0;i<=15;i++){
                editText_sayilar.setText(editText_sayilar.getText()+"\n"+i);
        }
    }
}